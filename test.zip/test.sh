#!/bin/bash
cd /tmp/
mkdir test-d

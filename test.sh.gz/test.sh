#/bin/bash
cd /tmp
mkdir 1test
